﻿using System;

namespace P02_DatabaseFirst
{
   public class StartUp
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
